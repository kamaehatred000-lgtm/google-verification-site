import express from "express";
import session from "express-session";
import { OAuth2Client } from "google-auth-library";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

const {
  GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET,
  BASE_URL,
  SESSION_SECRET = "change-this-secret"
} = process.env;

const client = new OAuth2Client(
  GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET,
  `${BASE_URL}/auth/google/callback`
);

app.use(session({
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { secure: true, httpOnly: true, sameSite: "lax", maxAge: 24*60*60*1000 }
}));

app.use(express.static(path.join(__dirname, "public")));

app.get("/auth/google", (req, res) => {
  const url = client.generateAuthUrl({
    access_type: "online",
    scope: ["openid", "email", "profile"],
    prompt: "select_account"
  });
  res.redirect(url);
});

app.get("/auth/google/callback", async (req, res) => {
  try {
    const { code } = req.query;
    if (!code) return res.redirect("/?status=error");

    const { tokens } = await client.getToken(code);
    const ticket = await client.verifyIdToken({
      idToken: tokens.id_token,
      audience: GOOGLE_CLIENT_ID
    });

    const payload = ticket.getPayload();
    req.session.user = {
      name: payload.name || "Пользователь",
      email: payload.email || "",
      picture: payload.picture || ""
    };

    res.redirect("/?status=success");
  } catch (e) {
    console.error(e);
    res.redirect("/?status=error");
  }
});

app.get("/me", (req, res) => {
  if (!req.session.user) return res.status(401).json({ loggedIn:false });
  res.json({ loggedIn:true, user:req.session.user });
});

app.post("/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok:true }));
});

app.listen(process.env.PORT || 3000, () =>
  console.log("Google verification site started")
);

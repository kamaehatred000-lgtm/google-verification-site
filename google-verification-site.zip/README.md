# Google Verification Site

Простой сайт с авторизацией через Google.

## Настройка Google

1. Откройте Google Cloud Console.
2. Создайте проект.
3. Настройте OAuth consent screen.
4. Создайте OAuth Client ID типа Web application.
5. Добавьте Authorized redirect URI:

https://ВАШ-ДОМЕН/auth/google/callback

## Переменные окружения

GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
BASE_URL=https://ВАШ-ДОМЕН
SESSION_SECRET=сложная_случайная_строка

Важно: Google сам определяет, потребуется ли дополнительная проверка аккаунта. Сайт не может отключить требования Google.

Сайт только выполняет Google-авторизацию. Он не просит пароль Google напрямую.
